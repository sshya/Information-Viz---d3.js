<?php
// Start the session
session_start();
?>
<?php
if (isset($_POST['genkeys'])){

$privateKey = openssl_pkey_new(array(
    'private_key_bits' => 2048,      // Size of Key.
    'private_key_type' => OPENSSL_KEYTYPE_RSA,
));

openssl_pkey_export_to_file($privateKey, 'private.key');

//openssl_pkey_export_to_file($privateKey, 'private.pem');
 
// Generate the public key for the private key
$a_key = openssl_pkey_get_details($privateKey);

file_put_contents('public.key', $a_key['key']);
$_SESSION["genkeys"] = TRUE;
}

if (isset($_POST['encdec'])){

$privateKey = openssl_pkey_new(array(
    'private_key_bits' => 2048,      // Size of Key.
    'private_key_type' => OPENSSL_KEYTYPE_RSA,
));

openssl_pkey_export_to_file($privateKey, 'private.key');

//openssl_pkey_export_to_file($privateKey, 'private.pem');
 
// Generate the public key for the private key
$a_key = openssl_pkey_get_details($privateKey);

file_put_contents('public.key', $a_key['key']);
$_SESSION["genkeys"] = TRUE;

  // Data to be sent
$plaintext = $_POST['message'];
 
//echo 'Plain text: ' . $plaintext;
// Compress the data to be sent
$plaintext = gzcompress($plaintext);
 
// Get the public Key of the recipient
// $publicKey = openssl_pkey_get_public('file:///path/to/public.key');
// $a_key = openssl_pkey_get_details($publicKey);

$publicKey = openssl_pkey_get_public($a_key['key']);
 
// Encrypt the data in small chunks and then combine and send it.
$chunkSize = ceil($a_key['bits'] / 8) - 11;
$output = '';
 
while ($plaintext)
{
    $chunk = substr($plaintext, 0, $chunkSize);
    $plaintext = substr($plaintext, $chunkSize);
    $encrypted = '';
    if (!openssl_public_encrypt($chunk, $encrypted, $publicKey))
    {
        die('Failed to encrypt data');
    }
    $output .= $encrypted;
}

if (isset($_POST["check"])){


//create signature
openssl_sign($plaintext, $signature, $privateKey, "sha1WithRSAEncryption");

//verify signature
$ok = openssl_verify($plaintext, $signature, $publicKey, OPENSSL_ALGO_SHA1);
if ($ok == 1) {
    $valid = "Signature Verified";
} elseif ($ok == 0) {
    $valid = "invalid";
} else {
    $valid = "error: ".openssl_error_string();
}
}
openssl_free_key($publicKey);
 
// This is the final encrypted data to be sent to the recipient
$encrypted = $output;
$hex_encrypted =bin2hex($encrypted);
//var_dump($hex_encrypted);


// if (!$privateKey = openssl_pkey_get_private('file:///path/to/private.key'))
// {
//     die('Private Key failed');
// }
//$a_key = openssl_pkey_get_details($privateKey);
 
// Decrypt the data in the small chunks
$chunkSize = ceil($a_key['bits'] / 8);
$output = '';
 
while ($encrypted)
{
    $chunk = substr($encrypted, 0, $chunkSize);
    $encrypted = substr($encrypted, $chunkSize);
    $decrypted = '';
    if (!openssl_private_decrypt($chunk, $decrypted, $privateKey))
    {
        die('Failed to decrypt data');
    }
    $output .= $decrypted;
}


openssl_free_key($privateKey);
 
// Uncompress the unencrypted data.
$output = gzuncompress($output);
 
//echo '<br /><br /> Unencrypted Data: ' . $output;
}
?>

<!DOCTYPE html>
<html lang="en" class="wide wow-animation">
  <head>
    <title>Contact-US</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700%7CUbuntu:400,500,700%7CPlayfair+Display:400,700,700i,900i">
    <link rel="stylesheet" href="css/style.css">
		<!--[if lt IE 10]>
    <div style="background: #212121; padding: 10px 0; box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3); clear: both; text-align:center; position: relative; z-index:1;"><a href="http://windows.microsoft.com/en-US/internet-explorer/"><img src="images/ie8-panel/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today."></a></div>
    <script src="js/html5shiv.min.js"></script>
		<![endif]-->
  </head>
  <body style="">
    <div class="page">
      <header class="page-head">
        <div class="rd-navbar-wrap">
          <nav data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static" data-stick-up-clone="false" data-md-stick-up-offset="53px" data-lg-stick-up-offset="53px" data-md-stick-up="true" data-lg-stick-up="true" class="rd-navbar rd-navbar-corporate-dark">
            <div class="rd-navbar-inner">
              <div class="rd-navbar-group rd-navbar-search-wrap">
                <div class="rd-navbar-panel">
                  <button data-custom-toggle=".rd-navbar-nav-wrap" data-custom-toggle-disable-on-blur="true" class="rd-navbar-toggle"><span></span></button><a href="index.html" class="rd-navbar-brand brand"><img src="images/logo.png" height="55px" style="height:35px;" /></a>
                </div>
                <div class="rd-navbar-nav-wrap">
                  <div class="rd-navbar-nav-inner">
                    <ul class="rd-navbar-nav">
                      <li ><a href="index.html">Home</a>
                      </li>
                      
                      <li><a href="symmetric.php">Symmetric</a>
                      </li>
                      <li class="active"><a href="asymmetric.php">Asymmetric</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>


      <section style="background-image: url(images/crism-background3.png);" class="section-30 section-sm-40 section-md-66 section-lg-bottom-90 bg-gray-dark page-title-wrap">
        <div class="shell">
          <div class="page-title">
            <h2>Asymmetic Cryptography</h2>
          </div>
          <a href="index.html" class="btn btn-icon btn-icon-left btn-cello"><span class="icon icon-xs-smaller fa-angle-left"></span>Back</a>
        </div>
      </section>

      <section class="section-35 section-sm-75 section-lg-100 bg-athens-gray">
        <div class="shell">
          <div class="range">
            <div class="cell-md-12 cell-lg-6">
              <h3>Start Here</h3>

              <form method="post" action="asymmetric.php" enctype="form/multipart" class="rd-mailform offset-top-45">
                <div class="offset-top-30 offset-sm-top-50">
                  <input type="hidden" name="frmname" value=""/>
                  <button type="submit" name="genkeys" value="save" class="btn btn-primary-outline btn-block">Generate Public/Private Key</button>
                </div>
              </form>
              <div class="offset-top-30">
                <div class="form-group">
                  <textarea id="feedback-2-message" name="message" data-constraints="@Required" class="form-control"><?php echo(isset($a_key['key'])?$a_key['key']:''); ?></textarea>
                  <label for="feedback-2-message" class="form-label"><?php echo(isset($a_key['key'])?'':'Public key'); ?></label>
                </div>
              </div>


              <form method="post" action="asymmetric.php" class="rd-mailform offset-top-45">
                <div class="range">
                  
                  <div class="cell-sm-12">
                    <label>Message</label>
                    <div class="form-group">
                      <input id="feedback-2-first-name" type="text" name="message" data-constraints="@Required" class="form-control" value="<?php echo(isset($_POST["message"])?$_POST["message"]:''); ?>">
                      <label for="feedback-2-first-name" class="form-label"></label>
                    </div>
                  </div>

                  <div class="cell-sm-12 offset-top-30">
                    <label>Encrypted</label>
                    <div class="form-group">
                      <input type="text" name="encrypted" class="form-control" value="<?php echo(isset($_POST["message"])?$hex_encrypted:''); ?>">
                      <label for="feedback-2-first-name" class="form-label"></label>
                    </div>
                  </div>

                  <div class="cell-sm-12 offset-top-30">
                    <label>Decrypted</label>
                    <div class="form-group">
                      <input type="text" name="decrypted" class="form-control" value="<?php echo(isset($_POST["message"])?$output:''); ?>">
                      <label for="feedback-2-first-name" class="form-label"></label>
                    </div>
                  </div>
                  <div class="cell-sm-12 offset-top-30">
                    
                    <div class="form-check">
                      <input type="checkbox" name="check" class="form-check-input" value=""> Check this to verify the signature
                      <label for="feedback-2-first-name" class="form-label"></label>
                    </div>
                  </div>

                  <div class="cell-sm-6 offset-top-30 offset-sm-top-10">
                    <h4><?php echo(isset($_POST["check"])?$valid :''); ?></h4>
                    <button type="submit" name="encdec" class="btn btn-primary-outline btn-block">Encrypt/Decrypt</button>
                  </div>

                </div>
              </form>
            </div>
          </div>
        </div>
      </section>

      

      

      <footer class="page-foot section-15 bg-cloud-burst">
        <div class="shell text-center">
          <div class="range">
            <div class="cell-sm-12">
              <p class="rights text-bismark"><span>&#169;&nbsp;</span><span id="copyright-year"></span><span>Old Dominion University.&nbsp;</span>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>

  </body>
</html>